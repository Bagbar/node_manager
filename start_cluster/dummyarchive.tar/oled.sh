#!/bin/sh

cat zed_dma_oled.bit > /dev/xdevcfg
echo bitstream loaded
