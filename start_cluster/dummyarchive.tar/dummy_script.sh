#!/bin/sh

echo script executed